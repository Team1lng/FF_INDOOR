#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("of:N*T*Canyka,ak39ev330-dac*");
MODULE_ALIAS("of:N*T*Canyka,ak39ev330-adc-dac*");
MODULE_ALIAS("of:N*T*Canyka,ak37d-adc-dac*");
MODULE_ALIAS("of:N*T*Canyka,ak37e-adc-dac*");

MODULE_INFO(srcversion, "2F242BC7A57A4BAD2EFAF0A");
