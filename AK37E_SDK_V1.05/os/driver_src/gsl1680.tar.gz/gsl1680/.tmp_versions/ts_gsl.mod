/home/share/Taba_project/AK37E_SDK_V1.05/os/driver_src/gsl1680/ts_gsl.ko
/home/share/Taba_project/AK37E_SDK_V1.05/os/driver_src/gsl1680/ts_gslX680.o /home/share/Taba_project/AK37E_SDK_V1.05/os/driver_src/gsl1680/gsl_point_id.o
